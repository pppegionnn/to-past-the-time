package com.example.clock;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import androidx.appcompat.app.AppCompatActivity;
import androidx.vectordrawable.graphics.drawable.ArgbEvaluator;

import android.content.pm.ActivityInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

public class FullscreenActivity extends AppCompatActivity {
    public TextView timetv;
    public TextView datetv;
    public LinearLayout flyot;
    public boolean exit=false;
    public boolean lightordark=false;
    public int timecol=0xff000001;
    public int datecol=0xff000001;
    public int lnlocol=0xcc000001;
    public static int txlight=0xfff0f0f0;
    public static int txdark =0xff707070;
    public static int dtlight=0xffa0b9cf;
    public        int bglight=0xaa0099cc;
    public static int bgdark =0xaa000000;
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        Objects.requireNonNull(getSupportActionBar()).hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_fullscreen);

        timetv = findViewById(R.id.time);
        datetv = findViewById(R.id.date);
        flyot = findViewById(R.id.alllt);

        try {
            Thread.sleep(800);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        flyot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(bglight==0xaa0099cc)bglight=0xaa00cc88;
                else bglight=0xaa0099cc;
                Message msg = new Message();
                msg.what = 0x00000001;
                mHandler.sendMessage(msg);
            }
        });

        Message msg = new Message();
        msg.what = 0x00000001;
        mHandler.sendMessage(msg);

        new updtime().start();
    }
    public class updtime extends Thread {
        @Override
        public void run() {
            while (!exit) {
                try {
                    Thread.sleep(1000);
                    Message msg = new Message();
                    msg.what = 0x00000001;
                    mHandler.sendMessage(msg);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    public static short timeCompare(String startTime, String endTime){
        @SuppressLint("SimpleDateFormat")
        SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        try {
            Date date1 = dateFormat.parse(startTime);
            Date date2 = dateFormat.parse(endTime);
            if(date1 == null||date2 == null)return 0;
            if (date2.getTime()<date1.getTime()){
                return 1;
            }else if (date2.getTime()==date1.getTime()){
                return 2;
            }else if (date2.getTime()>date1.getTime()){
                return 3;
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return 0;
    }
    @SuppressLint("HandlerLeak")
    public Handler mHandler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message message) {
            super.handleMessage(message);
            if (message.what==0x00000001) {
                String sysTimeStr = getStringTime();
                timetv.setText(sysTimeStr);
                String sysDateStr = getStringDate();
                datetv.setText(sysDateStr);
                setcol(sysTimeStr);
                new changecolor().start();
            }
        }
    };
    public void setcol(String systime){
        lightordark= (timeCompare(systime, "06:00:00") != 3 && timeCompare(systime, "21:00:00") == 3);
    }
    @SuppressLint("RestrictedApi")
    public class changecolor extends Thread{
        @Override
        public void start(){
            if (lightordark) {
                if (timecol != txlight) {
                    ValueAnimator ctimetv = ObjectAnimator.ofInt(timetv, "textColor",
                            timecol, txlight);
                    ctimetv.setDuration(900);
                    ctimetv.setEvaluator(new ArgbEvaluator());
                    ctimetv.setRepeatCount(0);
                    ctimetv.start();
                    timecol = txlight;
                }
                if (datecol != dtlight) {
                    ValueAnimator cdatetv = ObjectAnimator.ofInt(datetv, "textColor",
                            datecol, dtlight);
                    cdatetv.setDuration(900);
                    cdatetv.setEvaluator(new ArgbEvaluator());
                    cdatetv.setRepeatCount(0);
                    cdatetv.start();
                    datecol = dtlight;
                }
                if (lnlocol != bglight) {
                    ValueAnimator cflyot = ObjectAnimator.ofInt(flyot, "BackgroundColor",
                            lnlocol, bglight);
                    cflyot.setDuration(900);
                    cflyot.setEvaluator(new ArgbEvaluator());
                    cflyot.setRepeatCount(0);
                    cflyot.start();
                    lnlocol = bglight;
                }
            } else {
                if (timecol != txdark) {
                    ValueAnimator ctimetv = ObjectAnimator.ofInt(timetv, "textColor",
                            timecol, txdark);
                    ctimetv.setDuration(900);
                    ctimetv.setEvaluator(new ArgbEvaluator());
                    ctimetv.setRepeatCount(0);
                    ctimetv.start();
                    timecol = txdark;
                }
                if (datecol != txdark) {
                    ValueAnimator cdatetv = ObjectAnimator.ofInt(datetv, "textColor",
                            datecol, txdark);
                    cdatetv.setDuration(900);
                    cdatetv.setEvaluator(new ArgbEvaluator());
                    cdatetv.setRepeatCount(0);
                    cdatetv.start();
                    datecol = txdark;
                }
                if (lnlocol != bgdark) {
                    ValueAnimator cflyot = ObjectAnimator.ofInt(flyot, "BackgroundColor",
                            lnlocol, bgdark);
                    cflyot.setDuration(900);
                    cflyot.setEvaluator(new ArgbEvaluator());
                    cflyot.setRepeatCount(0);
                    cflyot.start();
                    lnlocol = bgdark;
                }
            }
        }
    }

    public static String getStringTime() {
        Date currentTime = new Date();
        @SuppressLint("SimpleDateFormat")
        SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");
        return formatter.format(currentTime);
    }
    public static String getStringDate() {
        Date currentTime = new Date();
        @SuppressLint("SimpleDateFormat")
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy.MM.dd E");
        return formatter.format(currentTime);
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        exit=true;
    }
}